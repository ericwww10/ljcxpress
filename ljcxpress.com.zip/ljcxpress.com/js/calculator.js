(() => {
  const amount = document.querySelector('[data-range="amount"]');
  const amountOutput = document.querySelector('[data-amount-output]');
  const repaymentPeriod = document.querySelector('#repaymentPeriod');
  const isEnglish = document.documentElement.lang.toLowerCase().startsWith('en');

  const formatRM = (value) => `RM ${Number(value).toLocaleString('en-MY')}`;
  const setRangeProgress = (input) => {
    if (!input) return;
    const min = Number(input.min || 0);
    const max = Number(input.max || 100);
    const value = Number(input.value || 0);
    const percent = ((value - min) / (max - min)) * 100;
    input.style.setProperty('--range-progress', `${percent}%`);
    input.setAttribute('aria-valuetext', formatRM(value));
  };

  const updateAmount = () => {
    if (!amount || !amountOutput) return;
    amountOutput.textContent = formatRM(amount.value);
    setRangeProgress(amount);
  };
  amount?.addEventListener('input', updateAmount);
  updateAmount();

  const form = document.querySelector('[data-application-form]');
  const status = document.querySelector('[data-form-status]');
  const phone = document.querySelector('#phone');
  const consent = form?.querySelector('input[name="consent"]');

  form?.addEventListener('submit', (event) => {
    event.preventDefault();
    if (!status) return;
    status.hidden = false;
    status.classList.remove('is-error');

    const digits = (phone?.value || '').replace(/\D/g, '');
    if (digits.length < 8 || digits.length > 13) {
      status.textContent = isEnglish
        ? 'Please enter a valid mobile number before continuing.'
        : 'Sila masukkan nombor telefon bimbit yang sah sebelum meneruskan.';
      status.classList.add('is-error');
      phone?.focus();
      return;
    }
    if (repaymentPeriod && !repaymentPeriod.value) {
      status.textContent = isEnglish
        ? 'Please select a repayment period.'
        : 'Sila pilih tempoh bayaran balik.';
      status.classList.add('is-error');
      repaymentPeriod.focus();
      return;
    }
    if (!consent?.checked) {
      status.textContent = isEnglish
        ? 'Please review and accept the privacy consent before continuing.'
        : 'Sila baca dan tandakan persetujuan privasi sebelum meneruskan.';
      status.classList.add('is-error');
      consent?.focus();
      return;
    }

    status.textContent = isEnglish
      ? 'This is a front-end prototype. No application has been submitted because the secure application backend is not connected yet.'
      : 'Ini ialah prototaip front-end. Tiada permohonan dihantar kerana sambungan backend permohonan yang selamat belum disediakan.';
  });
})();
