(() => {
  // FAQ accordions use native <details> for instantaneous, accessible disclosure.

  // Customer reviews: seamless infinite loop on desktop; swipe and manual navigation on mobile.
  document.querySelectorAll('[data-reviews-viewport]').forEach((viewport) => {
    const track = viewport.querySelector('[data-reviews-track]');
    if (!track) return;
    const originals = [...track.querySelectorAll(':scope > .customer-review:not([data-review-clone])')];
    if (originals.length < 2) return;
    const section = viewport.closest('.section-reviews');
    const isMobile = () => window.matchMedia('(max-width: 760px)').matches;
    const removeClones = () => track.querySelectorAll('[data-review-clone]').forEach((clone) => clone.remove());
    const setDesktopLoop = () => {
      removeClones();
      track.style.animation = 'none';
      track.style.transform = '';
      originals.forEach((card) => {
        const clone = card.cloneNode(true);
        clone.setAttribute('aria-hidden', 'true');
        clone.setAttribute('inert', '');
        clone.dataset.reviewClone = 'true';
        track.appendChild(clone);
      });
      track.dataset.loopReady = 'true';
      const setDistance = () => {
        const firstClone = track.children[originals.length];
        if (!firstClone) return;
        const distance = firstClone.getBoundingClientRect().left - track.children[0].getBoundingClientRect().left;
        track.style.setProperty('--review-distance', `${distance}px`);
        track.style.setProperty('--review-duration', `${Math.max(26, distance / 32)}s`);
        track.style.animation = '';
      };
      requestAnimationFrame(setDistance);
    };
    const setMobileManual = () => {
      removeClones();
      track.dataset.loopReady = 'false';
      track.style.animation = 'none';
      track.style.transform = '';
      track.style.removeProperty('--review-distance');
      viewport.scrollLeft = 0;
    };
    const setup = () => isMobile() ? setMobileManual() : setDesktopLoop();
    setup();
    let resizeTimer;
    window.addEventListener('resize', () => {
      window.clearTimeout(resizeTimer);
      resizeTimer = window.setTimeout(setup, 120);
    }, {passive:true});
    let reviewNavFrame = 0;
    const move = (direction) => {
      const first = track.querySelector('.customer-review:not([data-review-clone])');
      if (!first) return;
      const gap = parseFloat(getComputedStyle(track).gap) || 0;
      const amount = first.getBoundingClientRect().width + gap;
      if (isMobile()) {
        viewport.scrollBy({left: direction * amount, behavior:'smooth'});
        return;
      }

      // Advance or reverse the existing infinite animation by one card.
      // This avoids disabling the loop and snapping back to its starting point.
      const loop = track.getAnimations().find((animation) => animation.animationName === 'ljcx-review-loop');
      const duration = Number(loop?.effect?.getTiming?.().duration);
      const distance = parseFloat(getComputedStyle(track).getPropertyValue('--review-distance'));
      if (!loop || !Number.isFinite(duration) || duration <= 0 || !Number.isFinite(distance) || distance <= 0) return;

      if (reviewNavFrame) cancelAnimationFrame(reviewNavFrame);
      loop.pause();
      let startTime = Number(loop.currentTime) || 0;
      const stepTime = amount * duration / distance;
      // When moving left at the beginning of a cycle, use the equivalent
      // position one cycle later so the reverse movement remains short.
      if (direction < 0 && startTime < stepTime) startTime += duration;
      const endTime = startTime + (direction * stepTime);
      const startedAt = performance.now();
      const travelDuration = 520;
      const animateReviewStep = (now) => {
        const progress = Math.min(1, (now - startedAt) / travelDuration);
        const eased = progress < 0.5
          ? 4 * progress * progress * progress
          : 1 - Math.pow(-2 * progress + 2, 3) / 2;
        loop.currentTime = startTime + ((endTime - startTime) * eased);
        if (progress < 1) {
          reviewNavFrame = requestAnimationFrame(animateReviewStep);
        } else {
          reviewNavFrame = 0;
          loop.play();
        }
      };
      reviewNavFrame = requestAnimationFrame(animateReviewStep);
    };
    section?.querySelector('[data-review-prev]')?.addEventListener('click', () => move(-1));
    section?.querySelector('[data-review-next]')?.addEventListener('click', () => move(1));
  });

  // Full-width Apply Now banner is visible immediately on page load; dismissible for this page view.
  const banner = document.querySelector('[data-sticky-banner]');
  const close = banner?.querySelector('[data-sticky-close]');
  if (banner) {
    banner.classList.add('is-visible');
    banner.setAttribute('aria-hidden', 'false');
    document.body.classList.add('sticky-banner-visible');
  }
  close?.addEventListener('click', () => {
    banner?.classList.add('is-dismissed');
    banner?.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('sticky-banner-visible');
  });

  // Make the entire product card clickable without interfering with its inner links.
  document.querySelectorAll('[data-card-link]').forEach((card) => {
    const go = () => { const href = card.getAttribute('data-card-link'); if (href) window.location.href = href; };
    card.addEventListener('click', (event) => { if (event.target.closest('a,button')) return; go(); });
    card.addEventListener('keydown', (event) => { if (event.target !== card) return; if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); go(); } });
  });

  // Keep the app listing URL configurable from the root HTML data attribute.
  const officialAppUrl = document.documentElement.dataset.appStoreUrl || '';
  if (officialAppUrl) document.querySelectorAll('[data-app-store-link]').forEach((link) => { link.href = officialAppUrl; link.target = '_blank'; link.rel = 'noopener noreferrer'; });
})();
