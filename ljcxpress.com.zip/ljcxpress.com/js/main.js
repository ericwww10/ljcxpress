(() => {
  document.documentElement.classList.add('js-ready');
  const year = document.querySelector('[data-current-year]');
  if (year) year.textContent = new Date().getFullYear();

  const revealItems = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries, currentObserver) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          currentObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -45px 0px' });
    revealItems.forEach((item) => observer.observe(item));
  } else {
    revealItems.forEach((item) => item.classList.add('is-visible'));
  }

  // The floating application CTA appears only after the visitor has moved beyond the hero.
  const stickyApply = document.querySelector('[data-sticky-apply]');
  const hero = document.querySelector('.hero-section');
  const updateStickyApply = () => {
    if (!stickyApply) return;
    const threshold = Math.max(420, Math.round((hero?.offsetHeight || 520) * 0.72));
    const show = window.scrollY > threshold;
    stickyApply.classList.toggle('is-visible', show);
    stickyApply.setAttribute('aria-hidden', String(!show));
    document.body.classList.toggle('sticky-apply-visible', show);
  };
  window.addEventListener('scroll', updateStickyApply, { passive: true });
  window.addEventListener('resize', updateStickyApply);
  updateStickyApply();

  // WhatsApp CTA links are updated to the official direct chat only after its number is provided.
  const whatsappNumber = document.documentElement.dataset.whatsappNumber || '';
  const digits = whatsappNumber.replace(/\D/g, '');
  if (digits) {
    document.querySelectorAll('[data-whatsapp-link]').forEach((link) => {
      link.href = `https://wa.me/${digits}`;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.removeAttribute('data-whatsapp-number-pending');
    });
  }
})();
