(() => {
  const body = document.body;
  // Inactive placeholders must never append an empty # to the URL.
  // They are not language switching or real fragment navigation controls.
  document.addEventListener('click', (event) => {
    const placeholder = event.target.closest('a[href="#"]');
    if (placeholder) event.preventDefault();
  }, true);

  const sidebar = document.querySelector('.mobile-sidebar');
  const backdrop = document.querySelector('[data-menu-backdrop]');
  const menuOpen = document.querySelector('[data-menu-open]');
  const menuClose = document.querySelector('[data-menu-close]');
  let lastFocus = null;

  const openSidebar = () => {
    if (!sidebar) return;
    lastFocus = document.activeElement;
    body.classList.add('menu-open');
    sidebar.setAttribute('aria-hidden', 'false');
    menuOpen?.setAttribute('aria-expanded', 'true');
    sidebar.querySelector('a,button')?.focus();
  };
  const closeSidebar = () => {
    body.classList.remove('menu-open');
    sidebar?.setAttribute('aria-hidden', 'true');
    menuOpen?.setAttribute('aria-expanded', 'false');
    lastFocus?.focus?.();
  };

  menuOpen?.addEventListener('click', openSidebar);
  menuClose?.addEventListener('click', closeSidebar);
  backdrop?.addEventListener('click', closeSidebar);
  sidebar?.querySelectorAll('a[href^="#"]').forEach((link) => link.addEventListener('click', closeSidebar));

  document.querySelectorAll('[data-products-toggle]').forEach((button) => {
    button.addEventListener('click', () => {
      const group = button.closest('.sidebar-products');
      const expanded = button.getAttribute('aria-expanded') === 'true';
      button.setAttribute('aria-expanded', String(!expanded));
      group?.classList.toggle('is-open', !expanded);
      group?.querySelector('.sidebar-product-links')?.setAttribute('aria-hidden', String(expanded));
    });
  });

  // Desktop product menu: click to expand; close on outside click or Escape.
  document.querySelectorAll('[data-desktop-products-toggle]').forEach((button) => {
    const wrapper = button.closest('.nav-product-dropdown');
    const menu = wrapper?.querySelector('.nav-product-menu');
    button.addEventListener('click', (event) => {
      event.stopPropagation();
      const open = button.getAttribute('aria-expanded') === 'true';
      button.setAttribute('aria-expanded', String(!open));
      if (menu) menu.hidden = open;
    });
  });
  document.addEventListener('click', (event) => {
    document.querySelectorAll('.nav-product-dropdown').forEach((wrapper) => {
      if (wrapper.contains(event.target)) return;
      const button = wrapper.querySelector('[data-desktop-products-toggle]');
      const menu = wrapper.querySelector('.nav-product-menu');
      button?.setAttribute('aria-expanded', 'false');
      if (menu) menu.hidden = true;
    });
  });

  document.querySelectorAll('[data-language-toggle]').forEach((button) => {
    button.addEventListener('click', (event) => {
      event.stopPropagation();
      const wrapper = button.closest('.language-switcher');
      const willOpen = !wrapper?.classList.contains('is-open');
      document.querySelectorAll('.language-switcher.is-open').forEach((item) => {
        if (item !== wrapper) {
          item.classList.remove('is-open');
          item.querySelector('[data-language-toggle]')?.setAttribute('aria-expanded', 'false');
        }
      });
      wrapper?.classList.toggle('is-open', willOpen);
      button.setAttribute('aria-expanded', String(willOpen));
    });
  });

  document.addEventListener('click', (event) => {
    if (!event.target.closest('.language-switcher')) {
      document.querySelectorAll('.language-switcher.is-open').forEach((item) => {
        item.classList.remove('is-open');
        item.querySelector('[data-language-toggle]')?.setAttribute('aria-expanded', 'false');
      });
    }
  });

  const dialog = document.querySelector('[data-login-dialog]');
  const loginOpenButtons = document.querySelectorAll('[data-login-open]');
  const loginCloseButtons = document.querySelectorAll('[data-login-close]');
  let loginFocus = null;
  const openLogin = () => {
    if (!dialog) return;
    loginFocus = document.activeElement;
    dialog.hidden = false;
    dialog.querySelector('.dialog-close')?.focus();
  };
  const closeLogin = () => {
    if (!dialog) return;
    dialog.hidden = true;
    loginFocus?.focus?.();
  };
  loginOpenButtons.forEach((button) => button.addEventListener('click', openLogin));
  loginCloseButtons.forEach((button) => button.addEventListener('click', closeLogin));

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      closeSidebar();
      closeLogin();
      document.querySelectorAll('.nav-product-dropdown').forEach((wrapper) => { wrapper.querySelector('[data-desktop-products-toggle]')?.setAttribute('aria-expanded','false'); const menu=wrapper.querySelector('.nav-product-menu'); if(menu) menu.hidden=true; });
      document.querySelectorAll('.language-switcher.is-open').forEach((item) => {
        item.classList.remove('is-open');
        item.querySelector('[data-language-toggle]')?.setAttribute('aria-expanded', 'false');
      });
    }
    if (event.key === 'Tab' && body.classList.contains('menu-open') && sidebar) {
      const focusables = [...sidebar.querySelectorAll('a[href],button:not([disabled])')].filter((el) => el.offsetParent !== null);
      if (!focusables.length) return;
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault(); last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault(); first.focus();
      }
    }
  });
})();
