(function () {
  const grid = document.querySelector('#blog-article-grid');
  const button = document.querySelector('[data-blog-show-more]');
  if (!grid || !button) return;

  const cards = Array.from(grid.querySelectorAll('.blog-directory-card'));
  const batchSize = 9;
  let visibleCount = Math.min(batchSize, cards.length);

  function render() {
    cards.forEach((card, index) => {
      card.hidden = index >= visibleCount;
    });
    button.hidden = visibleCount >= cards.length;
  }

  button.addEventListener('click', function () {
    visibleCount = Math.min(visibleCount + batchSize, cards.length);
    render();
  });

  render();
})();
