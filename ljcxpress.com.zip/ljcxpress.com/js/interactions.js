(() => {
  const backTop = document.querySelector('[data-back-to-top]');
  backTop?.addEventListener('click', () => window.scrollTo({top:0,behavior:'smooth'}));
  const updateBackTop = () => backTop?.classList.toggle('is-visible', window.scrollY > 500);
  window.addEventListener('scroll', updateBackTop, {passive:true});
  updateBackTop();
})();
