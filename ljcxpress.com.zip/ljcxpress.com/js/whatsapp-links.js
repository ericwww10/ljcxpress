(() => {
  'use strict';
  const raw = String(window.LJCXpressConfig?.whatsappNumber || document.documentElement.dataset.whatsappNumber || '');
  const number = raw.replace(/\D/g, '');
  // WhatsApp's wa.me endpoint requires an actual international phone number.
  // Until confirmed, keep the meaningful contact-page fallback; never open an invalid URL.
  document.querySelectorAll('[data-whatsapp-link]').forEach(link => {
    if (!number) {
      link.dataset.whatsappNumberPending = 'true';
      return;
    }
    link.href = `https://wa.me/${number}`;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.removeAttribute('data-whatsapp-number-pending');
  });
})();
