/* LJCXpress global contact settings. Set whatsappNumber to 60XXXXXXXXX once verified. */
window.LJCXpressConfig = Object.freeze({ whatsappNumber: '' });
