/* V30: keep cross-page Reviews / Application links anchored after layout settles. */
(() => {
  const supported = new Set(['#reviews', '#application']);
  const alignHash = () => {
    const hash = window.location.hash;
    if (!supported.has(hash)) return;
    const section = document.getElementById(hash.slice(1));
    if (!section) return;
    section.scrollIntoView({ block: 'start', behavior: 'instant' });
  };
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', alignHash, { once: true });
  } else {
    alignHash();
  }
  window.addEventListener('load', alignHash, { once: true });
  window.addEventListener('hashchange', alignHash);
})();
